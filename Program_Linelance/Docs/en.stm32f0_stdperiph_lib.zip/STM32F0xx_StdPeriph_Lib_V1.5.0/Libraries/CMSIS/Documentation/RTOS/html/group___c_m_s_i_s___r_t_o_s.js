var group___c_m_s_i_s___r_t_o_s =
[
    [ "Kernel Information and Control", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl" ],
    [ "Thread Management", "group___c_m_s_i_s___r_t_o_s___thread_mgmt.html", "group___c_m_s_i_s___r_t_o_s___thread_mgmt" ],
    [ "Generic Wait Functions", "group___c_m_s_i_s___r_t_o_s___wait.html", "group___c_m_s_i_s___r_t_o_s___wait" ],
    [ "Timer Management", "group___c_m_s_i_s___r_t_o_s___timer_mgmt.html", "group___c_m_s_i_s___r_t_o_s___timer_mgmt" ],
    [ "Signal Management", "group___c_m_s_i_s___r_t_o_s___signal_mgmt.html", "group___c_m_s_i_s___r_t_o_s___signal_mgmt" ],
    [ "Mutex Management", "group___c_m_s_i_s___r_t_o_s___mutex_mgmt.html", "group___c_m_s_i_s___r_t_o_s___mutex_mgmt" ],
    [ "Semaphore Management", "group___c_m_s_i_s___r_t_o_s___semaphore_mgmt.html", "group___c_m_s_i_s___r_t_o_s___semaphore_mgmt" ],
    [ "Memory Pool Management", "group___c_m_s_i_s___r_t_o_s___pool_mgmt.html", "group___c_m_s_i_s___r_t_o_s___pool_mgmt" ],
    [ "Message Queue Management", "group___c_m_s_i_s___r_t_o_s___message.html", "group___c_m_s_i_s___r_t_o_s___message" ],
    [ "Mail Queue Management", "group___c_m_s_i_s___r_t_o_s___mail.html", "group___c_m_s_i_s___r_t_o_s___mail" ],
    [ "Generic Data Types and Definitions", "group___c_m_s_i_s___r_t_o_s___definitions.html", "group___c_m_s_i_s___r_t_o_s___definitions" ],
    [ "Status and Error Codes", "group___c_m_s_i_s___r_t_o_s___status.html", "group___c_m_s_i_s___r_t_o_s___status" ]
];