/*****************************************************
Project : Line Follower Robot
Version : 1
Date    : 04.02.2020
Author  : vladubase@gmail.com
Company : StudLab@BNTU
Comments:
	1. All measurements in  millimeters, milliamps, grams, rad/s, kg*cm;
	2. Keywords and abbreviations:
		Line - means black line on the white surface of competition field,
		SensorLine - this is the board on which the line sensors (optocouplers) are located,
		M - Motor;


Chip type               : ATmega328P
Program type            : Application
AVR Core Clock frequency: 20.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*****************************************************/


	#include		"headers/mega328p.h"
	#include		"headers/mega328p_bits.h"
	#include		"headers/delay.h"
	#include		"headers/math.h"

	#define			F_CPU							16000000UL				// Clock frequency of quartz resonator

// GENERAL INFORMATION
	//#define			DIAMETER_OF_WHEELS				46						// Diameter of wheels in mm
	//#define			TRACK_WIDTH						70						// Distance from the center of the drive wheels
	#define			WHEEL_AXLE_TO_SENSORS			100						// Distance from drive wheels to the sensor line
																			//(to the center between UV LED and sensor)
	#define			QTY_OF_SENSORS					8						// Quantity of sensors
	#define			DISTANCE_BTW_SENSORS			8.13					// Distance between the centers of two nearby sensors
	//#define			WEIGHT_OF_ROBOT					130						// Weight of Robot in grams
	//#define			MOTOR_SUPPLY_VOLTAGE			7.4						// Voltage supplied to motor

// MOTOR CPECIFICATION
	//#define			M_RATED_VOLTAGE					6						//
	//#define			M_GEAR_RATIO					29.86					// X to 1 (X:1)
	//#define			M_NO_LOAD_SPEED					1065					// Rounds per minute
	//#define			M_NO_LOAD_CURRENT				80						// In milliamps
	//#define			M_LOCK_CURRENT					1600					//
	//#define			M_NO_LOAD_TORQUE				0.60					// Torque in kg*cm
	//#define			M_WINDING_RESISTANCE			4.625					// In Ohms
	//#define			M_SHAFT_DIAMETER				3						//
	#define			M_LEFT_QUOTIENT					1.0						// Power factor of the left motor
	#define			M_RIGHT_QUOTIENT				1.0						// Power factor of the right motor
																			//designed to compensate for differences in motors

// DEFINING THE SEQUENCE OF SENSORS
	// From left to right
	// Edit if you use a different number of sensors
	#define			ReadSen1				//
	#define			ReadSen2				//
	#define			ReadSen3				//
	#define			ReadSen4				//
	#define			ReadSen5				//
	#define			ReadSen6				//
	#define			ReadSen7				//
	#define			ReadSen8				//
	//#define			ReadSen9				//
	//#define			ReadSen10				//
	//#define			ReadSen11				//
	//#define			ReadSen12				//
	//#define			ReadSen13				//
	//#define			ReadSen14				//
	//#define			ReadSen15				//
	//#define			ReadSen16				//

// DEFINING PERIPHERAL PORTS
	#define			PINC1							ReadIRSen				// Infrared sensor
	//#define			PINxx							ReadMEncoderL			// Left motor encoder
	//#define			PINxx							ReadMEncoderR			// Right motor encoder
	//#define			PINxx							ReadSen					//
	//#define			PINxx							ReadSen					//
	//#define			PINxx							ReadSen					//
	//#define			PINxx							ReadSen					//
	//#define			PINxx							ReadSen					//

// GLOBAL VARIABLES
	float SensorLineSize = QTY_OF_SENSORS * DISTANCE_BTW_SENSORS,			// Calculating distance between extreme sensors
		  RotationAngle = 0.0;												// Angle of rotation needed to adjust direction
	unsigned short int SensorLineFeedback = 0x0000;							// Store data of Line location

void Presetup (void) {														// MICROCONTROLLER SETUP FUNCTION
	// IO PORTS INITIALIZATION
		// Motors
			DDRB |= (1 << DDB4);			//OC2A
			DDRD |= (1 << DDD6) |			//OC0A
					(1 << DDD5) |			//OC0B
					(1 << DDD3);			//OC2B
	/*
		// SensorLine
			DDRB |= (1 << DDBx) |
					(1 << DDBx);
			DDRC |= (1 << DDCx) |
					(1 << DDCx);
			DDRD |= (1 << DDDx) |
					(1 << DDDx);

		// Periphery
			DDRB |= (1 << DDBx) |
					(1 << DDBx);
			DDRC |= (1 << DDCx) |
					(1 << DDCx);
			DDRD |= (1 << DDDx) |
					(1 << DDDx);
	*/
	// TIMER/COUNTER INITIALIZATION
		// Timer/Counter 0
		// PWM, Phase Correct
		// Top = 0xFF
		// Prescaler frequency 1:1024  equals
			TCCR0A |= (1 << COM0A1) | (1 << COM0B1) | (1 << WGM00);
			TCCR0A &= ~((1 << COM0A0) | (1 << COM0B0) | (1 << 3) | (1 << 2) | (1 << WGM01));
			TCCR0B |= (1 << CS02) | (1 << CS00);
			TCCR0B &= ~((1 << FOC0A) | (1 << FOC0B) | (1 << 5) | (1 << 4) | (1 << WGM02) | (1 << CS01));
			TCNT0  = 0x00;
			OCR0A  = 0x00;    OCR0B  = 0x00;

		// Timer/Counter 1
			// Turn OFF
			TCCR1A = 0x00;
			TCCR1B = 0x00;
			TCNT1H = 0x00;    TCNT1L = 0x00;
			ICR1H  = 0x00;    ICR1L  = 0x00;
			OCR1AH = 0x00;    OCR1AL = 0x00;
			OCR1BH = 0x00;    OCR1BL = 0x00;

		// Timer/Counter 2
			// PWM, Phase Correct
			// Top = 0xFF
			// Prescaler frequency 1:1024
			TCCR2A |= (1 << COM2A1) | (1 << COM2B1) | (1 << WGM20);
			TCCR2A &= ~((1 << COM2A0) | (1 << COM2B0) | (1 << 3) | (1 << 2) | (1 << WGM21));
			TCCR2B |= (1 << CS22) | (1 << CS21) | (1 << CS20);
			TCCR2B &= ~((1 << FOC2A) | (1 << FOC2B) | (1 << 5) | (1 << 4) | (1 << WGM22));
			TCNT2  = 0x00;
			OCR2A  = 0x00;    OCR2B  = 0x00;

	// Crystal Oscillator division factor: 1
		#pragma optsize-
			CLKPR  = 0x80;
			CLKPR  = 0x00;
		#ifdef _OPTIMIZE_SIZE_
		#pragma optsize+
		#endif

	// External Interrupt(s) initialization
		// Turn OFF
		EICRA  = 0x00;
		EIMSK  = 0x00;
		PCICR  = 0x00;

	// Timer/Counter 0 Interrupt(s) initialization
		// Turn OFF
		TIMSK0 = 0x00;

	// Timer/Counter 1 Interrupt(s) initialization
		// Turn OFF
		TIMSK1 = 0x00;

	// Timer/Counter 2 Interrupt(s) initialization
		// Turn OFF
		TIMSK2 = 0x00;

	// USART initialization
		// Turn OFF
		UCSR0B = 0x00;

	// Analog Comparator initialization
		// Turn OFF
		ACSR   = 0x80;
		ADCSRB = 0x00;
		DIDR1  = 0x00;

	// ADC initialization
		// Turn OFF
		ADCSRA = 0x00;

	// SPI initialization
		// Turn OFF
		SPCR   = 0x00;

	// TWI initialization
		// Turn OFF
		TWCR   = 0x00;
}

void EquationOfMovement (void) {											// CALCULATING THE ANGLE OF ROTATION
	register unsigned char i = 0;
	register float MPowerCoefficient = 1.1;									// Ratio to adjust the motion formula

	// FIND ANGLE OF ROTATION
		// Positive if line is to the left of the center,
		//and negative if to the right of the center

		switch (SensorLineFeedback)	{										// If the line is at a particular one sensor.
		case 1:																//e.g. SensorLineFeedback == 0b000000100000		(0d32)
		case 2:
		case 4:
		case 8:
		case 16:
		case 32:
		case 64:
		case 128:
		case 256:
		case 512:
		case 1024:
		case 2048:
		case 4096:
		case 8192:
		case 16384:
		case 32768:
			break;
		default:
			for (i = QTY_OF_SENSORS; i > 0; i--) {
			// If the line is on both adjacent sensors AND to the left of the center of the robot
				if (SensorLineFeedback == (0b11 << (i - 2)) && SensorLineFeedback > (0b11 << (QTY_OF_SENSORS / 2 - 1)) ) {
					SensorLineFeedback = (0b1 << (i - 1) );
				}
			// If the line is on both adjacent sensors AND to the right of the center of the robot
				else if (SensorLineFeedback == (0b11 << (i - 2)) && SensorLineFeedback < (0b11 << (QTY_OF_SENSORS / 2 - 1)) ) {
					SensorLineFeedback = (0b1 << (i - 1) );
				}

			}
			break;
		}

		RotationAngle = tan (((SensorLineSize / 2) - (log2f (SensorLineFeedback) * DISTANCE_BTW_SENSORS )) / WHEEL_AXLE_TO_SENSORS) + 0.040672;

	// EQUATION OF MOVEMENT
		if (RotationAngle >= 0) {
			OCR0A = 255;
			OCR0B = 0;
			OCR2A = 255 / (1 + RotationAngle) * MPowerCoefficient;
			OCR2B = 0;
		}
		else {
			OCR0A = 255 / (1 + RotationAngle) * MPowerCoefficient;
			OCR0B = 0;
			OCR2A = 255;
			OCR2B = 0;
		}

	// MAKE A MOTOR POWER ADJUSTMENT
		if (M_LEFT_QUOTIENT >= M_RIGHT_QUOTIENT) {
		// Left Motor
			OCR2A = 255;
			OCR2B = 0;
		// Right Motor
			OCR0A = OCR0A / M_LEFT_QUOTIENT;
			OCR0B = 0;
	}
	else {
		// Left Motor
			OCR2A = OCR2A / M_RIGHT_QUOTIENT;
			OCR2B = 0;
		// Right Motor
			OCR0A = 255;
			OCR0B = 0;
	}
}


/*       			MAIN PROGRAM  			    */
void main (void) {
	// DETERMINING VARIABLES
		unsigned char LinePos [QTY_OF_SENSORS] = {0};						// Variable determining the position of the Line
		unsigned short int SensorLineFeedback = 0x0000;						// Save data from sensor Line
		register unsigned char i = 0;										// Iterator. Instruct the compiler to store the variable
																			//in processor registers, rather than in RAM, if possible
	// PRESETUP
		Presetup ();

	// WAITING FOR A SIGNAL ON IR SENSOR
		#ifdef IRSen
			while (IRSen){
				PORTB4 |= (1 << 4);
					delay_ms(250);
				PORTB4 &= ~(1 << 4);
					delay_ms(250);
			}
		#endif

	//delay_ms(5000);

	// SET MAX VOLTAGE ON MOTORS
		OCR0A = 255;
		OCR0B = 0;
		OCR2A = 255;
		OCR2B = 0;

	// MAIN CYCLE
	while (1) {
		// RESET DATA
			SensorLineFeedback = 0x0000;
			RotationAngle = 0.0;

			for (i = QTY_OF_SENSORS; i > 0; i -= 2) {						// Processing two iterations per loop
				if ( (QTY_OF_SENSORS - i) == 1) {							// This is intended to avoid overflow of the LinePos variable.
					i += 1;													// Its protection if we have an odd number of sensors
				}															//e.g. QTY_OF_SENSORS = 5, at the moment i = 1, so make an increment of i
																			//In next iteration i = 2 and we will record data
																			//from 0(again) and 1st positions (1st and 2nd sensors)
		// READ DATA FROM SENSORS
			LinePos [i - 1] = ("ReadSen" + i);								// To access the value from the sensor we sum the strings.
			LinePos [i - 2] = ("ReadSen" + (i - 1));						//Receive data from Sen1, Sen5, etc.
			SensorLineFeedback |= ((LinePos [i] << i - 1) |					// Save data from sensors
										  (LinePos [i - 1] << (i - 2)));
			}

			EquationOfMovement ();

		/*
			MotorsSumTorque = 2 * M_NO_LOAD_TORQUE * G / 100										// ~0.117768	N*m
			Сила, с которой машинка ускоряется = MotorsSumTorque * 1000 / DIAMETER_OF_WHEELS		// ~2.560173	N
			Ускорение машинки = Сила, с которой машинка ускоряется / WEIGHT_OF_ROBOT				// ~19.693645	m*sec^2
		*/
	}
}
