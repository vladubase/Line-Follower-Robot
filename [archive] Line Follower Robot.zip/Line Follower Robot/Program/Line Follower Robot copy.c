/*****************************************************
Project : Line Follower Robot
Version : 1
Date    : 04.02.2020
Author  : vladubase@gmail.com
Company : StudLab@BNTU
Comments:
	1. All measurements in  millimeters, milliamps, grams, rad/s, kg*cm;
	2. Keywords and abbreviations:
		Line - means black line on the white surface of competition field,
		SensorLine - this is the board on which the line sensors (optocouplers) are located,
		M - Motor;


Chip type               : ATmega328P
Program type            : Application
AVR Core Clock frequency: 20.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*****************************************************/


	#include		"headers/mega328p.h"
	#include		"headers/mega328p_bits.h"
	#include		"headers/delay.h"
	#include		"headers/math.h"

	#define			F_CPU							16000000UL				// Clock frequency of quartz resonator

// GENERAL INFORMATION
	//#define				DIAMETER_OF_WHEELS				46						// Diameter of wheels in mm
	//#define				TRACK_WIDTH						70						// Distance from the center of the drive wheels
	//#define				WHEEL_AXLE_TO_SENSORS			100						// Distance from drive wheels to the sensor line
																				//(to the center between UV LED and sensor)
	#define				QTY_OF_SENSORS					8						// Quantity of sensors
	//#define				DISTANCE_BTW_SENSORS			8.13					// Distance between the centers of two nearby sensors
	//#define				WEIGHT_OF_ROBOT					130						// Weight of Robot in grams
	//#define				MOTOR_SUPPLY_VOLTAGE			7.4						// Voltage supplied to motor

// MOTOR CPECIFICATION
	//#define				M_RATED_VOLTAGE					6						//
	//#define				M_GEAR_RATIO					29.86					// X to 1 (X:1)
	//#define				M_NO_LOAD_SPEED					1065					// Rounds per minute
	//#define				M_NO_LOAD_CURRENT				80						// In milliamps
	//#define				M_LOCK_CURRENT					1600					//
	//#define				M_NO_LOAD_TORQUE				0.60					// Torque in kg*cm
	//#define				M_WINDING_RESISTANCE			4.625					// In Ohms
	//#define				M_SHAFT_DIAMETER				3						//
	#define				M_LEFT_QUOTIENT					1.0						// Power factor of the left motor
	#define				M_RIGHT_QUOTIENT				1.0						// Power factor of the right motor
																			//designed to compensate for differences in motors

// DEFINING THE SEQUENCE OF SENSORS
	// From left to right
	// Edit if you use a different number of sensors
	//#define				ReadSen1						PINxx					//
	//#define				ReadSen2						PINxx					//
	//#define				ReadSen3						PINxx					//
	//#define				ReadSen4						PINxx					//
	//#define				ReadSen5						PINxx					//
	//#define				ReadSen6						PINxx					//
	//#define				ReadSen7						PINxx					//
	//#define				ReadSen8						PINxx					//
	//#define				ReadSen9						PINxx					//
	//#define				ReadSen10						PINxx					//
	//#define				ReadSen11						PINxx					//
	//#define				ReadSen12						PINxx					//
	//#define				ReadSen13						PINxx					//
	//#define				ReadSen14						PINxx					//
	//#define				ReadSen15						PINxx					//
	//#define				ReadSen16						PINxx					//

// DEFINING PERIPHERAL PORTS
	//#define				PINxx							ReadIRSen				// Infrared sensor
	//#define				PINxx							ReadMEncoderL			// Left motor encoder
	//#define				PINxx							ReadMEncoderR			// Right motor encoder
	//#define				PINxx							ReadSen					//
	//#define				PINxx							ReadSen					//
	//#define				PINxx							ReadSen					//
	//#define				PINxx							ReadSen					//
	//#define				PINxx							ReadSen					//


void Presetup (void) {														// MICROCONTROLLER SETUP FUNCTION
	// IO PORTS INITIALIZATION
		// Motors
			DDRB |= (1 << DDB4);			//OC2A
			DDRD |= (1 << DDD6) |			//OC0A
					(1 << DDD5) |			//OC0B
					(1 << DDD3);			//OC2B
	/*
		// SensorLine
			DDRB |= (1 << DDBx) |
					(1 << DDBx);
			DDRC |= (1 << DDCx) |
					(1 << DDCx);
			DDRD |= (1 << DDDx) |
					(1 << DDDx);

		// Periphery
			DDRB |= (1 << DDBx) |
					(1 << DDBx);
			DDRC |= (1 << DDCx) |
					(1 << DDCx);
			DDRD |= (1 << DDDx) |
					(1 << DDDx);
	*/
	// TIMER/COUNTER INITIALIZATION
		// Timer/Counter 0
		// Fast PWM
		// Top = 0xFF
		// Prescaler frequency 1:1024  equals
			TCCR0A |= (1 << COM0A1) | (1 << COM0B1) | (1 << WGM00) | (1 << WGM01);
			TCCR0A &= ~((1 << COM0A0) | (1 << COM0B0) | (1 << 3) | (1 << 2));
			TCCR0B |= (1 << CS02) | (1 << CS00);
			TCCR0B &= ~((1 << FOC0A) | (1 << FOC0B) | (1 << 5) | (1 << 4) | (1 << WGM02) | (1 << CS01));
			TCNT0  = 0x00;
			OCR0A  = 0x00;    OCR0B  = 0x00;

		// Timer/Counter 1
			// Turn OFF
			TCCR1A = 0x00;
			TCCR1B = 0x00;
			TCNT1H = 0x00;    TCNT1L = 0x00;
			ICR1H  = 0x00;    ICR1L  = 0x00;
			OCR1AH = 0x00;    OCR1AL = 0x00;
			OCR1BH = 0x00;    OCR1BL = 0x00;

		// Timer/Counter 2
			// Fast PWM
			// Top = 0xFF
			// Prescaler frequency 1:1024
			TCCR2A |= (1 << COM2A1) | (1 << COM2B1) | (1 << WGM20) | (1 << WGM21);
			TCCR2A &= ~((1 << COM2A0) | (1 << COM2B0) | (1 << 3) | (1 << 2));
			TCCR2B |= (1 << CS22) | (1 << CS21) | (1 << CS20);
			TCCR2B &= ~((1 << FOC2A) | (1 << FOC2B) | (1 << 5) | (1 << 4) | (1 << WGM22));
			TCNT2  = 0x00;
			OCR2A  = 0x00;    OCR2B  = 0x00;

	// Crystal Oscillator division factor: 1
		#pragma optsize-
			CLKPR  = 0x80;
			CLKPR  = 0x00;
		#ifdef _OPTIMIZE_SIZE_
		#pragma optsize+
		#endif

	// External Interrupt(s) initialization
		// Turn OFF
		EICRA  = 0x00;
		EIMSK  = 0x00;
		PCICR  = 0x00;

	// Timer/Counter 0 Interrupt(s) initialization
		// Turn OFF
		TIMSK0 = 0x00;

	// Timer/Counter 1 Interrupt(s) initialization
		// Turn OFF
		TIMSK1 = 0x00;

	// Timer/Counter 2 Interrupt(s) initialization
		// Turn OFF
		TIMSK2 = 0x00;

	// USART initialization
		// Turn OFF
		UCSR0B = 0x00;

	// Analog Comparator initialization
		// Turn OFF
		ACSR   = 0x80;
		ADCSRB = 0x00;
		DIDR1  = 0x00;

	// ADC initialization
		// Turn OFF
		ADCSRA = 0x00;

	// SPI initialization
		// Turn OFF
		SPCR   = 0x00;

	// TWI initialization
		// Turn OFF
		TWCR   = 0x00;
}



/*       			MAIN PROGRAM  			    */
void main (void) {
	// DETERMINING VARIABLES
		register unsigned short int SensorLineFeedback = 0x0000;			// Save data from sensor Line

	// PRESETUP
		Presetup ();

	// WAITING FOR A SIGNAL ON IR SENSOR
		#ifdef IRSen
			while (IRSen){
				PORTxx |= (1 << x);
					delay_ms(250);
				PORTxx &= ~(1 << x);
					delay_ms(250);
			}
		#endif

	delay_ms(1000);

	// SET MAX VOLTAGE ON MOTORS
		if (M_LEFT_QUOTIENT >= M_RIGHT_QUOTIENT) {
			// Left Motor
				OCR2A = 255;
				OCR2B = 0;
			// Right Motor
				OCR0A /= M_LEFT_QUOTIENT;
				OCR0B = 0;
		}
		else {
			// Left Motor
				OCR2A /= M_RIGHT_QUOTIENT;
				OCR2B = 0;
			// Right Motor
				OCR0A = 255;
				OCR0B = 0;
		}

	// MAIN CYCLE
	while (1) {
		// RESET DATA
			SensorLineFeedback = 0x0000;

		// READ DATA FROM SENSORS
			SensorLineFeedback |= PINC0 | (PINC1 << 1) | (PINC2 << 2) | (PINC3 << 3) | (PINC4 << 4) | (PINC5 << 5) | (PIND4 << 6) | (PIND2 << 7);
			
		// FORMULA OF MOVEMENT
			// If on the right of the Line
			if (SensorLineFeedback >= pow (2, 4)) {
				while (SensorLineFeedback < 16) {
					OCR2A = 0;
					OCR2B = 0;
					OCR0A = 255;
					OCR0B = 0;
				}
			}
			// If on the left of the Line
			else if (SensorLineFeedback < pow (2, 4)) {
				while (SensorLineFeedback > 16) {
					OCR2A = 255;
					OCR2B = 0;
					OCR0A = 0;
					OCR0B = 0;
				}
			}
					
	}
}
